import pyspark
from pyspark.sql import SparkSession
from pyspark.sql.types import IntegerType
from pyspark.sql.functions import *
import logging
import logging.config
import psycopg2
import pandas
import pandas.io.sql as sqliq
class Ingestion:
    logging.config.fileConfig("C:/users/SAURABH_SHARMA/resources/config/logging.conf")

    def __init__(self,spark):
        self.spark=spark
    def data_ingest(self):
        logger=logging.getLogger("Ingest")
        logger.info("Ingestion Started")
        #customer_df = self.spark.read.csv("Retaildata.csv",header=True)
        course_df=self.spark.sql("select * from huron.course")
        logging.info("DataFrame Created")
        return course_df

    # def read_from_pg(self):
    #     connection=psycopg2.connect(user='postgres',password='admin',host='localhost',database='postgres')
    #     cursor=connection.cursor()
    #     sql_query = ("SELECT * from futurexschema.futurex_course_catalog")
    #     pandas_df = sqliq.read_sql_query(sql_query , connection)
    #     sparkDf = self.spark.createDataFrame(pandas_df)
    #     return sparkDf

    def read_from_jdbcdriver(self):
        jdbc_df = self.spark.read \
                  .format("jdbc") \
                  .option("url","jdbc:postgresql://localhost:5432/postgres") \
                  .option("dbtable","futurexschema.futurex_course_catalog") \
                  .option("user","postgres") \
                  .option("password","admin") \
                  .load()
        # jdbc_df.show()
        return jdbc_df










