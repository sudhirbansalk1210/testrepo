import pyspark
from pyspark.sql import SparkSession
from pyspark.sql.types import IntegerType
from pyspark.sql.functions import *
import logging
import logging.config

class Transformation:
    logging.config.fileConfig("C:/users/SAURABH_SHARMA/resources/config/logging.conf")

    def __init__(self,spark):
        self.spark=spark
    def data_transform(self,df):
        logger=logging.getLogger("Transform")
        logger.info("Data Transformation running")
        df1=df.na.fill("Unknown",["course_name"])
        #df1=df.na.drop()
        logger.info("Data Transformation Done")
        return df1

