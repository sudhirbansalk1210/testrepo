import unittest
import Transformation
import Ingestion
import Persist
from pyspark.sql import SparkSession

class TransformTest(unittest.TestCase):
    def test_transform_should_replace_nullvalue(self):
        spark = SparkSession.Builder(). \
            appName("test_Transformation") \
            .enableHiveSupport().getOrCreate()

        df=spark.read.option("header","true").option("inferSchema","true").csv("mockdata.csv")
        df.show()

        transform_process=Transformation.Transformation(spark)
        transformed_df=transform_process.data_transform(df)
        transformed_df.show()

        sb_course=transformed_df.filter("course_id='2'").select("course_name").collect()[0].course_name
        print("Coursename for 'SB' Authorname is " +str(sb_course))
        self.assertEqual("Unknown",str(sb_course))

    def test_should_throw_type_error(self):
        spark = SparkSession.builder \
            .appName("testing app") \
            .enableHiveSupport().getOrCreate()

        tranform_process = Transformation.Transformation(spark)
        with self.assertRaises(AttributeError):
            tranform_process.data_transform(None)


if __name__ == '__main__':
    unittest.main()

