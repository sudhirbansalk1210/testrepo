import unittest

class TransformationTest(unittest.TestCase):
    def first_test(self):
        self.assertEqual(3,3)

    def test_second(self):
        self.assertTrue("PYTHON".isupper())

if __name__== '__main__':
     unittest.main()

