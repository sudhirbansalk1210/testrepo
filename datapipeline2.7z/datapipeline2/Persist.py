import pyspark
from pyspark.sql import SparkSession
from pyspark.sql.types import IntegerType
from pyspark.sql.functions import *
import logging
import logging.config
import sys
import psycopg2
import pandas
import configparser


class Persist:
    logging.config.fileConfig("C:/users/SAURABH_SHARMA/resources/config/logging.conf")

    def __init__(self,spark):
        self.spark=spark
    def data_persist(self,df):
        try:
            logger = logging.getLogger("Persist")
            #config=configparser.ConfigParser()
            #config.read("resources\pipeline.ini")
            #target_table = config.get('DB_CONFIGS','TARGET_PG_TABLE')

            #print("PG_TARGET_TABLE IS" +str(target_table))


            logger.info("Data Persist running")
            #df.coalesce(1).write.mode("overwrite").option("header","true").csv("transformed_retailstore.csv")
            df.write.mode("append").format("jdbc").option("url","jdbc:postgresql://localhost:5432/postgres") \
                  .option("dbtable","futurexschema.futurex_course") \
                  .option("user","postgres") \
                  .option("password","admin") \
                  .save()

            logger.info("Data Persist done")
        except Exception as exp:
            logger.error("An error occured while Persisting DF-> "+str(exp))
            #sys.exit(1)
            #raise Exception("HDFS directory already exists")

    def insert_into_pg(self):
        logger=logging.getLogger("Persist")
        logger.info("Started Writing into Postgres Database")
        connection = psycopg2.connect(user='postgres', password='admin', host='localhost', database='postgres')
        cursor = connection.cursor()
        insert_query = "INSERT INTO futurexschema.futurex_course_catalog (course_id, course_name, author_name, course_section, creation_date) VALUES (%s, %s, %s, %s,%s)"
        insert_tuple = (4, 'Deep Learning', 'Saurabh', '{}', '2020-10-21')
        cursor.execute(insert_query, insert_tuple)
        logger.info("Completed Writing into Postgres Database")
        cursor.close()
        connection.commit()


