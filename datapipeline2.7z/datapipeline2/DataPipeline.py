import Ingestion
import Transformation
import Persist
import pyspark
from pyspark.sql import SparkSession
from pyspark.sql.types import IntegerType
from pyspark.sql.functions import *
import logging
import logging.config
import sys

class DataPipeline:
    logging.config.fileConfig("C:/users/SAURABH_SHARMA/resources/config/logging.conf")
    def run_pipeline(self):
        try:
            logging.info("Run pipeline started")
            ingest = Ingestion.Ingestion(self.spark)
            df = ingest.data_ingest()
            logging.info("Ingestion Output")
            df.show()
            # df_postgres=ingest.read_from_pg()
            # df_postgres.show()
            #df=ingest.read_from_jdbcdriver()
            #df.show()
            transform = Transformation.Transformation(self.spark)
            transform_df = transform.data_transform(df)
            logging.info("Transformation Output")
            transform_df.show()
            persist = Persist.Persist(self.spark)
            #persist_df1=persist.insert_into_pg()
            persist_df=persist.data_persist(transform_df)
            logging.info("Persist pipeline ended")
        except Exception as exp:
            logging.error("Exception is "+str(exp))
            #Send email notification
            #Log the error in Database
            sys.exit(1)


        return

    def create_spark_session(self):
        self.spark=SparkSession.Builder().\
            appName("DataPipeline").\
            config("spark.driver.extraClassPath","postgresql-42.3.7.jar")\
            .enableHiveSupport().getOrCreate()

    # def create_hive_table(self):
    #     # self.spark.sql("create database if not exists huron")
    #     # self.spark.sql("create table if not exists huron.course "
    #     #                "(course_id string,course_name string,"
    #     #                "author_name string,no_of_review string) ")
    #     # self.spark.sql("INSERT INTO huron.course VALUES(1,'Python','S',20)")
    #     # self.spark.sql("INSERT INTO huron.course VALUES(2,'Cloud','',30)")
    #     # self.spark.sql("INSERT INTO huron.course VALUES(3,'Spark','B',40)")
    #     # self.spark.sql("INSERT INTO huron.course VALUES(4,'ML','S',20)")
    #     # self.spark.sql("INSERT INTO huron.course VALUES(5,'','D',30)")
    #     # self.spark.sql("INSERT INTO huron.course VALUES(6,'Microservices','E',40)")
    #     # #Treat Empty strings as null values
    #     # self.spark.sql("alter table huron.course set tblproperties('serialization.null.format'='')")





if __name__=='__main__':

    #logging.debug("Debugging the application")
    logging.info("Application Started")
    #logging.warning("Application Started with Warning")
    #logging.error("Application started with error")

    pipeline=DataPipeline()
    pipeline.create_spark_session()
    #pipeline.create_hive_table()
    logging.info("Spark Session Created")
    pipeline.run_pipeline()
    logging.info("Pipeline ended")
